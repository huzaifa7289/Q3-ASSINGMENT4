def get_name():
    return "Sophia"

def main():
    name = get_name()
    print(f"Howdy {name} ! 🤠")

if __name__ == '__main__':
    main()
