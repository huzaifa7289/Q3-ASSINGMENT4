adj = input("Enter an adjective: ")
verb1 = input("Enter a verb: ")
verb2 = input("Enter another verb: ")
famous_person = input("Enter a famous person: ")

madlib = f"Computer programming is so {adj}! It makes me so excited all the time because "  \
        f"I Love to {verb1}. and hydrated and {verb2} like you are {famous_person}!"

print(madlib)