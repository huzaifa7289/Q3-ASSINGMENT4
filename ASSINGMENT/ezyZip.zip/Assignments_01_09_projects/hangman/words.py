words = [
    'python', 'programming', 'computer', 'algorithm', 'database',
    'network', 'software', 'hardware', 'internet', 'developer',
    'coding', 'debugging', 'testing', 'deployment', 'version',
    'control', 'repository', 'function', 'variable', 'class'
] 